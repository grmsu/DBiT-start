---
name: "❓Analysis question"
about: Ask a question about the analysis of single-cell data
title: ''
labels: question
assignees: ''

---

<!-- Please search the previous issues for similar questions before opening a new issue. If there are similar previous issues, please reference them in your issue (https://help.github.com/en/github/writing-on-github/autolinked-references-and-urls) -->

<!-- Please clearly explain your question and include all relevant code. Please ensure that code is formatted correctly: https://help.github.com/en/github/writing-on-github/creating-and-highlighting-code-blocks -->
